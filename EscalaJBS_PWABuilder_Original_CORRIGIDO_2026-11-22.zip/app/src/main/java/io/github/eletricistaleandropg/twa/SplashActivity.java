package io.github.eletricistaleandropg.twa;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;

/**
 * First stage only: show the approved full icon for 2 seconds, then fade it
 * out over 500ms. The website's existing 4-second animation is not modified.
 */
public class SplashActivity extends Activity {
    private static final long ICON_HOLD_MS = 2000L;
    private static final long FADE_MS = 500L;
    private static final int BACKGROUND = Color.rgb(11, 18, 32); // #0b1220
    private static final int SYSTEM_BARS = Color.rgb(24, 49, 83); // #183153

    private final Handler handler = new Handler(Looper.getMainLooper());
    private boolean forwarded = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(SYSTEM_BARS);
        getWindow().setNavigationBarColor(SYSTEM_BARS);
        getWindow().getDecorView().setSystemUiVisibility(0); // status icons white

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(BACKGROUND);
        ImageView icon = new ImageView(this);
        icon.setImageResource(R.drawable.splash_approved);
        icon.setScaleType(ImageView.ScaleType.FIT_CENTER);

        DisplayMetrics metrics = getResources().getDisplayMetrics();
        // same visual proportion as the user-approved screen (~58% of width)
        int iconSizePx = Math.round(metrics.widthPixels * 0.58f);
        FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(
            iconSizePx, iconSizePx, Gravity.CENTER);
        root.addView(icon, params);
        setContentView(root);

        handler.postDelayed(() -> {
            if (isFinishing() || isDestroyed()) return;
            icon.animate().alpha(0f).setDuration(FADE_MS)
                .withEndAction(this::openOriginalTrustedWebActivity).start();
        }, ICON_HOLD_MS);
    }

    private void openOriginalTrustedWebActivity() {
        if (forwarded || isFinishing() || isDestroyed()) return;
        forwarded = true;
        Intent next = new Intent(this, LauncherActivity.class);
        startActivity(next);
        overridePendingTransition(0, 0);
        finish();
        overridePendingTransition(0, 0);
    }

    @Override
    protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        super.onDestroy();
    }
}
