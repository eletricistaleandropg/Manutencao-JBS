package io.github.eletricistaleandropg.twa;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;

/**
 * First stage: show approved icon for 2 seconds and hold the same visual
 * throughout Chrome handoff. Chrome fades its matching splash over 500ms when
 * the web page paints. The website's 4-second animation is not modified.
 */
public class SplashActivity extends Activity {
    private static final long ICON_HOLD_MS = 2000L;
    private static final int BACKGROUND = Color.rgb(11, 18, 32); // #0b1220
    private static final int SYSTEM_BARS = Color.rgb(24, 49, 83); // #183153

    private final Handler handler = new Handler(Looper.getMainLooper());
    private boolean forwarded = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(SYSTEM_BARS);
        getWindow().setNavigationBarColor(SYSTEM_BARS);
        getWindow().getDecorView().setSystemUiVisibility(0); // status icons white

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(BACKGROUND);
        ImageView icon = new ImageView(this);
        icon.setImageResource(R.drawable.splash_approved);
        icon.setScaleType(ImageView.ScaleType.FIT_CENTER);

        DisplayMetrics metrics = getResources().getDisplayMetrics();
        // same visual proportion as the user-approved screen (~58% of width)
        int iconSizePx = Math.round(metrics.widthPixels * 0.58f);
        FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(
            iconSizePx, iconSizePx, Gravity.CENTER);
        root.addView(icon, params);
        setContentView(root);

        handler.postDelayed(() -> {
            if (isFinishing() || isDestroyed()) return;
            // Hand over with the SAME image still visible. Chrome keeps it while
            // the website loads, and Chrome's 500ms splash fade handles the web transition.
            openOriginalTrustedWebActivity();
        }, ICON_HOLD_MS);
    }

    private void openOriginalTrustedWebActivity() {
        if (forwarded || isFinishing() || isDestroyed()) return;
        forwarded = true;
        Intent next = new Intent(this, LauncherActivity.class);
        // The Android Browser Helper TWA launcher requires NEW_TASK on entry.
        // Without it, it relaunches itself and can finish before opening Chrome.
        next.setAction(Intent.ACTION_MAIN);
        next.addCategory(Intent.CATEGORY_LAUNCHER);
        next.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(next);
        overridePendingTransition(0, 0);
        // Keep this dark window underneath the transparent LauncherActivity while
        // Chrome prepares its own identical splash. Do not finish here: doing so
        // exposed a white window between the two screens.
    }

    @Override
    protected void onStop() {
        super.onStop();
        // A is no longer needed once the browser covers it. Do not leave a
        // duplicate splash behind when the user presses Back from Chrome.
        if (forwarded && !isFinishing()) finish();
    }

    @Override
    protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        super.onDestroy();
    }
}
